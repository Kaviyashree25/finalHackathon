import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-post-section',
  templateUrl: './post-section.component.html',
  styleUrls: ['./post-section.component.css']
})
export class PostSectionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
