import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bank-login',
  templateUrl: './bank-login.component.html',
  styleUrls: ['./bank-login.component.css']
})
export class BankLoginComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
